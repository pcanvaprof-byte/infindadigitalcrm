@echo off
title INFINDA CRM - Conexao WhatsApp Silenciosa
color 0A
cls

echo ==========================================================
echo   INFINDA CRM - Servidor de Disparo Silencioso WhatsApp
echo ==========================================================
echo.

:: 1. Verifica se o Node.js esta instalado no computador
where node >nul 2>nul
if %errorlevel% neq 0 (
    color 0C
    echo [ATENCAO] O Node.js ainda nao esta instalado neste computador!
    echo.
    echo Baixe e instale a versao recomendada (LTS) no site:
    echo https://nodejs.org
    echo.
    echo Apos instalar o Node.js, execute este arquivo novamente.
    echo.
    start https://nodejs.org
    pause
    exit /b 1
)

:: 2. Vai para a pasta do script
cd /d "%~dp0"

:: 3. Se a pasta node_modules nao existir, instala automaticamente
if not exist "node_modules" (
    echo Instalando componentes pela primeira vez... Aguarde um instante.
    echo.
    call npm install --omit=dev
    if %errorlevel% neq 0 (
        color 0C
        echo.
        echo [ERRO] Falha ao baixar componentes. Verifique sua conexao de internet.
        pause
        exit /b 1
    )
    echo.
    echo Componentes instalados com sucesso!
    echo.
)

:: 4. Inicia o servidor do WhatsApp na porta 3000
echo Iniciando conexao do WhatsApp...
echo Mantenha esta janela aberta enquanto estiver usando o INFINDA CRM.
echo.
node server.mjs
pause
